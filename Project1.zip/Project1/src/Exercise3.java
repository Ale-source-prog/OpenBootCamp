public class Exercise3 {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente();
        Trabajador trabajador1 = new Trabajador();

        cliente1.edad= 32;
        cliente1.nombre= "Jose Rafael Guzman";
        cliente1.telefono= 64521354;
        cliente1.credito= 1454.78;

        System.out.println("Los datos del cliente son: ");
        System.out.printf("Tiene %d años, su nombre es %s, su telefono movil es %d, tiene un credito pendiente de %.2f euros", cliente1.edad, cliente1.nombre, cliente1.telefono, cliente1.credito);

        trabajador1.edad=45;
        trabajador1.nombre="Jose Gregorio Hernandez";
        trabajador1.telefono=68741394;
        trabajador1.salario= 1455.78;

        System.out.println("\nLos datos del trabajador son: ");
        System.out.printf("Tiene %d años, su nombre es %s, su telefono movil es %d, tiene un salario de %.2f euros", trabajador1.edad, trabajador1.nombre, trabajador1.telefono, trabajador1.salario);
    }
}
    class Persona {
        int edad;
        String nombre;
        int telefono;
    }
    class Cliente extends Persona{
        double credito;

    }
    class Trabajador extends Persona{
        double salario;
    }
